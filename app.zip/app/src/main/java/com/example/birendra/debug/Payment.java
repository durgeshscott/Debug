package com.example.birendra.debug;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.Button;
import android.widget.TextView;

/**
 * Created by Birendra on 1/20/2017.
 */
public class Payment extends AppCompatActivity {

   // Button cash,digital;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.payment_layout);

        TextView tv = (TextView)findViewById(R.id.textView4);
        String ftp = getIntent().getExtras().getString("f");
        tv.setText(ftp);

    }
}
