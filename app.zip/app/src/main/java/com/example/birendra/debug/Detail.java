package com.example.birendra.debug;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Calendar;

/**
 * Created by Birendra on 1/20/2017.
 */
public class Detail extends AppCompatActivity {

    TextView fine_detail;
    Button fine;
    String Fine=null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.detail_layout);

        fine_detail = (TextView)findViewById(R.id.textView2);
        fine = (Button)findViewById(R.id.button);


        Bundle extras = getIntent().getExtras();
        String prevfine = extras.getString("PrevFine");
        final String nextfine = extras.getString("NextFine");

        fine_detail.setText(prevfine);

        fine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent a = new Intent(Detail.this,Payment.class);
                a.putExtra("f",nextfine);
                startActivity(a);

            }

        });
    }



}
