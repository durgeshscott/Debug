package com.example.birendra.debug;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.firebase.client.Firebase;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

/**
 * Created by Birendra on 1/20/2017.
 */
public class Check extends AppCompatActivity {

    EditText vehicle_num;
    Button check;
    String vnum = null;

    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference("message");

    public float basic = 100, extra = 0, prevfine = 0;
    public int count = 0;
    public Vehicle vehicle = new Vehicle();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.input_layout);


        vehicle_num = (EditText) findViewById(R.id.editText);
        check = (Button) findViewById(R.id.button5);


        check.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                vnum = vehicle_num.getText().toString();
                checkAvailability();
            }

        });
    }

    public void checkAvailability() {

        try {

            // Firebase ref = new Firebase("https://debug-16e55.firebaseio.com");

            myRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot snapshot) {

                    for (DataSnapshot postSnapshot : snapshot.getChildren()) {

                        Vehicle vehicle = postSnapshot.getValue(Vehicle.class);
                        String num = vehicle.getNumber();

                        if (num == vnum)
                            viewDeatil();
                        else
                            update();
                    }
                }


                @Override
                public void onCancelled(DatabaseError databaseError) {
                    Toast.makeText(getApplicationContext(), "Failed to read.", Toast.LENGTH_SHORT).show();
                }

            });
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), "Failed to read.", Toast.LENGTH_SHORT).show();
        }

    }


    public void update() {

        try {

            vehicle.setNumber(vnum);
            vehicle.setCounter(vehicle.getCounter() + 1);
            vehicle.setPrevfine(calfine());

            myRef.child("Vehicle").setValue(vehicle);
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), "Here", Toast.LENGTH_SHORT).show();
        }
    }

    public float calfine() {
        try {
            count = vehicle.getCounter();

            if (count == 6) {
                count = 0;
                vehicle.setCounter(count);
                myRef.child("Vehicle").setValue(vehicle);
            }

            switch (count) {
                default:
                case 0:
                    extra = 0;
                    break;

                case 1:
                    extra = basic * 10 / 100;
                    break;

                case 2:
                    extra = basic * 20 / 100;
                    break;

                case 3:
                    extra = basic * 30 / 100;
                    break;

                case 4:
                    extra = basic * 40 / 100;
                    break;

                case 5:
                    extra = basic * 50 / 100;
                    break;
            }


        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), "Here2", Toast.LENGTH_SHORT).show();
        }
        return basic + extra;
    }



    public void viewDeatil() {
        try {

            Float prev = vehicle.getPrevfine();

            Intent intent = new Intent(Check.this, Detail.class);
            Bundle extras = new Bundle();
            extras.putString("PrevFine", prev.toString());
            extras.putString("NextFine", "ftp");
            intent.putExtras(extras);
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), "Here3", Toast.LENGTH_SHORT).show();
        }

    }
}
