package com.example.birendra.debug;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;


/**
 * Created by Birendra on 1/22/2017.
 */

public class Test extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.test);
    }
}
