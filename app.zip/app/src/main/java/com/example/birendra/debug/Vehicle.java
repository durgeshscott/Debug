package com.example.birendra.debug;

/**
 * Created by Birendra on 1/21/2017.
 */

public class Vehicle {

    private String number;
    private int counter;
    private float prevfine;

    public Vehicle() {
      /*Blank default constructor essential for Firebase*/
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public int getCounter() {
        return counter;
    }

    public void setCounter(int counter) {
        this.counter = counter;
    }

    public float getPrevfine() {
        return prevfine;
    }

    public void setPrevfine(float prevfine) {
        this.prevfine = prevfine;
    }
}
